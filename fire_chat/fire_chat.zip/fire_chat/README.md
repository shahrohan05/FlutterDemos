# fire_chat

A Firebase backed chat project using Flutter.
 - Icon Courtesy : [Vecteezy](https://www.vecteezy.com/vector-art/105140-hvac-flat-vector-icons)