import 'package:flutter/material.dart';

const Color kMainAccent = Color(0xFFE54D42);
const Color kLightTheme = Color(0xFFFEFBEA);
